import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from dataclasses import dataclass, asdict
from typing import Dict, List, Tuple
import warnings

warnings.filterwarnings("ignore")

plt.rcParams.update({
    "figure.dpi": 150,
    "font.size": 11,
    "axes.titlesize": 13,
    "axes.labelsize": 11,
    "legend.fontsize": 10,
    "axes.spines.top": False,
    "axes.spines.right": False,
})


# ============================================================
# Section 0: Core Data Structures & Evidence Scale
# ============================================================

EVIDENCE_SCALE: Dict[float, str] = {
    0.95: "Very Strong  – standardised third-party benchmark / explicit official task-specific evaluation",
    0.85: "Strong       – official technical report with direct task evidence",
    0.70: "Moderate     – indirect provider claim or less task-specific evidence",
    0.55: "Weak         – general or weakly comparable evidence",
    0.40: "Very Weak    – minimal or absent public evidence",
}


@dataclass(frozen=True)
class ScenarioConfig:
    """
    Configuration for one scenario (e.g., Coding Assistants).

    Attributes
    ----------
    name        : scenario name (for display / export)
    products    : list of product names
    dimensions  : list of dimension names
    weights     : list of weights (must sum to 1)
    scores_raw  : nested dict: {product -> [scores per dimension]}
    """
    name: str
    products: List[str]
    dimensions: List[str]
    weights: List[float]
    scores_raw: Dict[str, List[float]]

    def validate(self) -> None:
        """Basic sanity checks to avoid silent mistakes."""
        if not np.isclose(sum(self.weights), 1.0, atol=1e-9):
            raise ValueError(f"Weights for scenario '{self.name}' must sum to 1, "
                             f"got {sum(self.weights):.6f}.")
        if len(self.dimensions) != len(self.weights):
            raise ValueError(f"Scenario '{self.name}': "
                             f"{len(self.dimensions)} dims but {len(self.weights)} weights.")
        for p in self.products:
            if p not in self.scores_raw:
                raise KeyError(f"Scenario '{self.name}': product '{p}' has no scores_raw entry.")
            if len(self.scores_raw[p]) != len(self.dimensions):
                raise ValueError(
                    f"Scenario '{self.name}', product '{p}': "
                    f"{len(self.scores_raw[p])} scores but {len(self.dimensions)} dimensions."
                )
            # Evidence-scale sanity: warn if score not one of the canonical levels
            for v in self.scores_raw[p]:
                if v not in EVIDENCE_SCALE:
                    # 允许使用中间值，但给出提示，方便后期审查
                    print(f"[Warning] Scenario '{self.name}', product '{p}': "
                          f"score {v} is not in canonical EVIDENCE_SCALE levels.")


def compute_weighted_score(scores: List[float], weights: List[float]) -> float:
    """
    Weighted aggregate score for one product in one scenario.
    """
    return float(np.dot(scores, weights))


def build_scenario_df(cfg: ScenarioConfig) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Build tidy DataFrames for one scenario.

    Returns
    -------
    df_dim : dimension-level scores  (products × dimensions)
    df_agg : aggregate scores with ranking and baseline annotation
    """
    cfg.validate()

    df_dim = pd.DataFrame(cfg.scores_raw, index=cfg.dimensions).T
    df_dim.index.name = "Product"

    agg_scores = {
        p: compute_weighted_score(cfg.scores_raw[p], cfg.weights)
        for p in cfg.products
    }

    df_agg = (
        pd.DataFrame.from_dict(agg_scores, orient="index", columns=["Aggregate Score"])
        .rename_axis("Product")
    )

    df_agg["Rank"] = df_agg["Aggregate Score"].rank(ascending=False, method="min").astype(int)
    df_agg = df_agg.sort_values("Rank")

    # Single-metric baseline: product with highest single-dimension score
    best_single = df_dim.max(axis=1).idxmax()
    df_agg["Single-metric Baseline Winner"] = np.where(
        df_agg.index == best_single, "✓ (baseline)", ""
    )

    return df_dim, df_agg


# ============================================================
# Section 1: Scenario Configs (directly from the paper)
# ============================================================

coding_cfg = ScenarioConfig(
    name="Coding Assistants",
    products=["Claude Code", "Cursor", "Grok"],
    dimensions=[
        "Correctness",
        "Repo-level Issue Resolution",
        "Debugging / Self-repair",
        "Cross-language Generalisation",
    ],
    weights=[0.25, 0.25, 0.25, 0.25],
    scores_raw={
        # [correctness, repo-level, debugging, cross-lang]
        "Claude Code": [0.95, 0.95, 0.85, 0.70],
        "Cursor":      [0.70, 0.85, 0.95, 0.70],
        "Grok":        [0.55, 0.40, 0.55, 0.55],
    },
)

writing_cfg = ScenarioConfig(
    name="Academic Writing",
    products=["ChatGPT (GPT-5)", "Claude", "Gemini"],
    dimensions=[
        "Instruction Following",
        "Long-form Factuality",
        "Overall Writing Quality",
        "Citation Reliability",
    ],
    weights=[0.25, 0.25, 0.25, 0.25],
    scores_raw={
        "ChatGPT (GPT-5)": [0.85, 0.85, 0.85, 0.85],
        "Claude":          [0.80, 0.70, 0.95, 0.55],
        "Gemini":          [0.75, 0.70, 0.70, 0.55],
    },
)

image_cfg = ScenarioConfig(
    name="Image Generation",
    products=["Seedream", "Midjourney", "OpenAI Image Gen"],
    dimensions=[
        "Text Alignment",
        "Compositional Prompt Handling",
        "Human Preference / Perceptual Quality",
        "Detail Fidelity",
    ],
    weights=[0.25, 0.25, 0.25, 0.25],
    scores_raw={
        "Seedream":         [0.95, 0.90, 0.95, 0.95],
        "Midjourney":       [0.70, 0.65, 0.95, 0.80],
        "OpenAI Image Gen": [0.80, 0.75, 0.75, 0.70],
    },
)

video_cfg = ScenarioConfig(
    name="Video Generation",
    products=["Seedance 2.0", "Sora 2", "Veo 3"],
    dimensions=[
        "Temporal Consistency",
        "Controllability",
        "Per-frame Visual Quality",
        "Physical / Commonsense Realism",
    ],
    weights=[0.25, 0.25, 0.25, 0.25],
    scores_raw={
        "Seedance 2.0": [0.95, 0.90, 0.85, 0.85],
        "Sora 2":       [0.75, 0.65, 0.90, 0.95],
        "Veo 3":        [0.65, 0.55, 0.85, 0.80],
    },
)

SCENARIO_CONFIGS: List[ScenarioConfig] = [coding_cfg, writing_cfg, image_cfg, video_cfg]


# ============================================================
# Section 2: Build All Scenario DataFrames
# ============================================================

scenario_results = []  # list of (ScenarioConfig, df_dim, df_agg)

for cfg in SCENARIO_CONFIGS:
    dim_df, agg_df = build_scenario_df(cfg)
    scenario_results.append((cfg, dim_df, agg_df))


# ============================================================
# Section 3: Pretty Printing Summary Tables
# ============================================================

def print_scenario_summary():
    for cfg, dim_df, agg_df in scenario_results:
        print("=" * 72)
        print(f"Scenario: {cfg.name}")
        print("=" * 72)
        print("\n[Dimension-level Evidence Scores]")
        print(dim_df.to_string())
        print("\n[Aggregate Scores & Rankings]")
        print(agg_df.to_string())
        print()


print_scenario_summary()


# ============================================================
# Section 4: Colour Palette
# ============================================================

COLORS = {
    "Claude Code": "#4C72B0", "Cursor": "#55A868", "Grok": "#C44E52",
    "ChatGPT (GPT-5)": "#4C72B0", "Claude": "#55A868", "Gemini": "#C44E52",
    "Seedream": "#4C72B0", "Midjourney": "#55A868", "OpenAI Image Gen": "#C44E52",
    "Seedance 2.0": "#4C72B0", "Sora 2": "#55A868", "Veo 3": "#C44E52",
}


# ============================================================
# Section 5: Plotting Utilities
# ============================================================

def radar_chart(ax, categories, values_dict, title, color_map):
    N = len(categories)
    angles = np.linspace(0, 2 * np.pi, N, endpoint=False).tolist()
    angles += angles[:1]

    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(
        [c.replace(" / ", "\n") for c in categories], size=7.5
    )

    ax.set_ylim(0, 1)
    ax.set_yticks([0.4, 0.55, 0.7, 0.85, 0.95])
    ax.set_yticklabels([str(v) for v in [0.4, 0.55, 0.7, 0.85, 0.95]], size=6.5)
    ax.set_title(title, size=11, pad=14, fontweight="bold")

    for product, vals in values_dict.items():
        v = vals + vals[:1]
        color = color_map.get(product, "grey")
        ax.plot(angles, v, "o-", linewidth=1.8, color=color, label=product)
        ax.fill(angles, v, alpha=0.12, color=color)

    ax.legend(loc="upper right", bbox_to_anchor=(1.35, 1.15), fontsize=7)


def bar_chart(ax, agg_df, title, color_map, threshold: float = 0.75):
    products = agg_df.index.tolist()
    scores = agg_df["Aggregate Score"].tolist()
    colors = [color_map.get(p, "steelblue") for p in products]

    # reverse for most important at top
    bars = ax.barh(products[::-1], scores[::-1],
                   color=colors[::-1], edgecolor="white", height=0.5)

    for bar, score in zip(bars, scores[::-1]):
        ax.text(bar.get_width() + 0.005, bar.get_y() + bar.get_height() / 2,
                f"{score:.4f}", va="center", ha="left", fontsize=9)

    ax.set_xlim(0, 1.05)
    ax.set_xlabel("Aggregate Score")
    ax.set_title(title, fontweight="bold")
    if threshold is not None:
        ax.axvline(x=threshold, color="grey", linestyle="--",
                   linewidth=0.8, alpha=0.6)


def plot_figures():
    # Figure 1: Radar charts
    fig1, axes = plt.subplots(2, 2, figsize=(14, 11), subplot_kw=dict(polar=True))
    fig1.suptitle("Figure 1 – Dimension-level Evidence Profiles (Radar Charts)",
                  fontsize=14, fontweight="bold", y=1.02)

    for ax, (cfg, _, _) in zip(axes.flat, scenario_results):
        radar_chart(ax, cfg.dimensions, cfg.scores_raw, cfg.name, COLORS)

    plt.tight_layout()
    plt.savefig("fig1_radar_charts.png", bbox_inches="tight")
    plt.show()

    # Figure 2: Aggregate score bar charts
    fig2, axes2 = plt.subplots(2, 2, figsize=(13, 9))
    fig2.suptitle("Figure 2 – Aggregate Scores & Rankings per Scenario",
                  fontsize=14, fontweight="bold")

    for ax, (cfg, _, agg_df) in zip(axes2.flat, scenario_results):
        bar_chart(ax, agg_df, cfg.name, COLORS)

    plt.tight_layout()
    plt.savefig("fig2_bar_charts.png", bbox_inches="tight")
    plt.show()


plot_figures()


# ============================================================
# Section 6: Full Evidence Score Heatmap
# ============================================================

def plot_heatmap():
    all_rows = []
    for cfg, dim_df, _ in scenario_results:
        for product in dim_df.index:
            for dim in dim_df.columns:
                all_rows.append({
                    "Scenario":  cfg.name,
                    "Product":   product,
                    "Dimension": dim,
                    "Score":     dim_df.loc[product, dim],
                })
    all_df = pd.DataFrame(all_rows)

    pivot = all_df.pivot_table(
        index=["Scenario", "Product"], columns="Dimension", values="Score"
    )

    fig, ax = plt.subplots(figsize=(16, 7))
    im = ax.imshow(pivot.values, aspect="auto", cmap="RdYlGn",
                   vmin=0.40, vmax=0.95)

    cbar = plt.colorbar(im, ax=ax)
    cbar.set_label("Evidence-coded Score (0.40–0.95)")

    ax.set_xticks(range(len(pivot.columns)))
    ax.set_xticklabels(pivot.columns, rotation=35, ha="right", fontsize=8)

    ax.set_yticks(range(len(pivot.index)))
    ax.set_yticklabels(
        [f"{s} | {p}" for s, p in pivot.index], fontsize=8
    )

    # annotate cells
    for i in range(pivot.shape[0]):
        for j in range(pivot.shape[1]):
            val = pivot.values[i, j]
            if not np.isnan(val):
                text_color = "black" if 0.55 < val < 0.85 else "white"
                ax.text(j, i, f"{val:.2f}", ha="center", va="center",
                        fontsize=7.5, color=text_color)

    ax.set_title(
        "Figure 3 – Full Evidence Score Heatmap (All Scenarios × Dimensions)",
        fontsize=13, fontweight="bold", pad=12
    )
    plt.tight_layout()
    plt.savefig("fig3_heatmap.png", bbox_inches="tight")
    plt.show()


plot_heatmap()


# ============================================================
# Section 7: Framework vs Single-metric Baseline (Figure 4)
# ============================================================

def build_baseline_comparison() -> pd.DataFrame:
    """
    Build a tidy DataFrame describing
    framework winner / runner-up vs single-metric baseline.
    """
    rows = []
    for cfg, dim_df, agg_df in scenario_results:
        # Framework winner & runner-up
        fw_sorted = agg_df.sort_values("Aggregate Score", ascending=False)
        fw_winner = fw_sorted.index[0]
        fw_winner_score = fw_sorted.iloc[0]["Aggregate Score"]
        fw_runner = fw_sorted.index[1]
        fw_runner_score = fw_sorted.iloc[1]["Aggregate Score"]

        # Single-metric baseline winner (already stored in agg_df)
        baseline_mask = agg_df["Single-metric Baseline Winner"] != ""
        baseline_winner = agg_df[baseline_mask].index[0]
        baseline_score = dim_df.loc[baseline_winner].max()

        rows.append({
            "Scenario": cfg.name,
            "Framework Winner": fw_winner,
            "Framework Score": fw_winner_score,
            "Framework Runner-up": fw_runner,
            "Framework Runner-up Score": fw_runner_score,
            "Baseline Winner": baseline_winner,
            "Baseline Score": baseline_score,
        })

    return pd.DataFrame(rows)


def plot_baseline_comparison():
    df = build_baseline_comparison()

    x = np.arange(len(df))
    width = 0.25

    fig, ax = plt.subplots(figsize=(12, 6))

    b1 = ax.bar(x - width,
                df["Framework Score"],
                width,
                label="Framework Winner",
                color="#4C72B0", edgecolor="white")
    b2 = ax.bar(x,
                df["Baseline Score"],
                width,
                label="Single-metric Baseline",
                color="#DD8452", edgecolor="white")
    b3 = ax.bar(x + width,
                df["Framework Runner-up Score"],
                width,
                label="Framework Runner-up",
                color="#55A868", edgecolor="white")

    ax.set_xticks(x)
    ax.set_xticklabels(df["Scenario"], fontsize=10)
    ax.set_ylim(0, 1.10)
    ax.set_ylabel("Score")
    ax.set_title("Figure 4 – Framework vs Single-metric Baseline Comparison",
                 fontsize=13, fontweight="bold")
    ax.legend()
    ax.axhline(y=0.75, color="grey", linestyle="--", linewidth=0.8, alpha=0.6)

    for bar_group in [b1, b2, b3]:
        for rect in bar_group:
            h = rect.get_height()
            ax.text(rect.get_x() + rect.get_width() / 2, h + 0.01,
                    f"{h:.3f}", ha="center", va="bottom", fontsize=8)

    # Annotate divergence cases
    for i, row in df.iterrows():
        if row["Framework Winner"] != row["Baseline Winner"]:
            ax.text(x[i], max(row["Framework Score"], row["Baseline Score"]) + 0.07,
                    "Winner\ndiverges!", ha="center", fontsize=8,
                    color="red", fontweight="bold")

    plt.tight_layout()
    plt.savefig("fig4_baseline_comparison.png", bbox_inches="tight")
    plt.show()

    return df


baseline_df = plot_baseline_comparison()


# ============================================================
# Section 8: Export Results
# ============================================================

def export_results():
    # Export per-scenario dimension & aggregate tables
    with pd.ExcelWriter("results_summary.xlsx", engine="openpyxl") as writer:
        for cfg, dim_df, agg_df in scenario_results:
            sheet_base = cfg.name.replace(" ", "_")[:20]
            dim_df.to_excel(writer, sheet_name=f"{sheet_base}_dim")
            agg_df.to_excel(writer, sheet_name=f"{sheet_base}_agg")

        # Also include baseline comparison sheet
        baseline_df.to_excel(writer, sheet_name="Baseline_Comparison", index=False)

    # Combined aggregate scores CSV
    all_agg_rows = []
    for cfg, _, agg_df in scenario_results:
        tmp = agg_df[["Aggregate Score", "Rank"]].copy()
        tmp["Scenario"] = cfg.name
        all_agg_rows.append(tmp)

    combined_agg = pd.concat(all_agg_rows).reset_index()
    combined_agg.to_csv("combined_aggregate_scores.csv", index=False)

    print("\nFigures saved: "
          "fig1_radar_charts.png, fig2_bar_charts.png, fig3_heatmap.png, "
          "fig4_baseline_comparison.png")
    print("Tabular results saved: results_summary.xlsx, combined_aggregate_scores.csv")
    print("\n=== Final Rankings Summary ===")
    print(combined_agg.to_string(index=False))


export_results()
