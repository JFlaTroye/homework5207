# Code Documentation (English Version)

**Project**: Benchmark-to-Practice: A Multi-Criteria Framework for Selecting AI Tools  
**Course**: DSAI5207 · Group 4  
**File**: `ai_selection_framework.py`  
**Date**: March 2026

---

## 1. Project Background

This code implements the **scenario-based multi-criteria AI product selection framework** proposed in the report. The framework covers four application scenarios:

| Scenario | Products Compared |
|----------|------------------|
| Coding Assistants | Claude Code · Cursor · Grok |
| Academic Writing | ChatGPT (GPT-5) · Claude · Gemini |
| Image Generation | Seedream · Midjourney · OpenAI Image Gen |
| Video Generation | Seedance 2.0 · Sora 2 · Veo 3 |

---

## 2. Dependencies

```bash
pip install numpy pandas matplotlib openpyxl
```

| Library | Version | Purpose |
|---------|---------|---------|
| numpy | ≥ 1.24 | Dot-product score computation |
| pandas | ≥ 2.0 | Tabular data management |
| matplotlib | ≥ 3.7 | Radar, bar, and heatmap charts |
| openpyxl | ≥ 3.1 | Excel export |

---

## 3. Code Structure

```
ai_selection_framework.py
├── Section 0  Global config & evidence scale reference
├── Section 1  Evidence coding data (4 scenarios × 3 products × 4 dimensions)
├── Section 2  Score computation engine
│   ├── compute_weighted_score()   Weighted aggregate score
│   └── build_scenario_df()        Scenario DataFrame builder
├── Section 3  Console summary output
├── Section 4  Visualisation (4 figures)
│   ├── Figure 1  Radar charts (dimension profiles)
│   ├── Figure 2  Horizontal bar charts (aggregate rankings)
│   ├── Figure 3  Heatmap (all scenarios × dimensions)
│   └── Figure 4  Framework vs single-metric baseline
└── Section 5  Result export (.xlsx + .csv)
```

---

## 4. Core Methodology

### 4.1 Evidence Coding Scale (5 levels)

| Code | Strength | Source Type |
|------|----------|-------------|
| **0.95** | Very Strong | Standardised third-party benchmark / explicit official task-specific evaluation |
| **0.85** | Strong | Official technical report with direct task evidence |
| **0.70** | Moderate | Indirect provider claim or less task-specific evidence |
| **0.55** | Weak | General or weakly comparable evidence |
| **0.40** | Very Weak | Minimal or absent public evidence |

### 4.2 Weighted Aggregate Score Formula

The core formula from the paper:

$$Score_{p,s} = \sum_{k=1}^{K_s} w_{k,s} \cdot x_k^{(p,s)}$$

Where:
- $$p$$ = product, $$s$$ = scenario, $$k$$ = dimension index
- $$x_k^{(p,s)}$$ = coded evidence score for product $$p$$ on dimension $$k$$ in scenario $$s$$
- $$w_{k,s} = 0.25$$ (equal weights; each scenario has exactly 4 dimensions)

Code implementation:
```python
def compute_weighted_score(scores: list, weights: list) -> float:
    assert abs(sum(weights) - 1.0) < 1e-9, "Weights must sum to 1."
    return float(np.dot(scores, weights))
```

### 4.3 Single-metric Baseline (Control)

The product achieving the highest score on **any single dimension** is selected as the baseline winner. This allows direct comparison of whether the multi-criteria framework changes or refines the recommendation.

---

## 5. Scenario Dimensions Explained

### Coding Assistants
| Dimension | Description |
|-----------|-------------|
| Correctness | Code correctness (unit test pass rate) |
| Repo-level Issue Resolution | Ability to resolve real GitHub issues (SWE-bench) |
| Debugging / Self-repair | Iterative debugging and self-correction |
| Cross-language Generalisation | Performance across multiple programming languages |

### Academic Writing
| Dimension | Description |
|-----------|-------------|
| Instruction Following | Accuracy in following complex writing instructions |
| Long-form Factuality | Factual precision in extended outputs (LongFact/SAFE) |
| Overall Writing Quality | Human-preference writing quality |
| Citation Reliability | Citation and attribution accuracy (PaperAsk benchmark) |

### Image Generation
| Dimension | Description |
|-----------|-------------|
| Text Alignment | Prompt-to-image faithfulness |
| Compositional Prompt Handling | Multi-object / relational prompt handling |
| Human Preference / Perceptual Quality | Aesthetic quality (HPS v2) |
| Detail Fidelity | Structural and fine-grained detail accuracy |

### Video Generation
| Dimension | Description |
|-----------|-------------|
| Temporal Consistency | Frame-to-frame coherence over time |
| Controllability | Responsiveness to detailed instructions |
| Per-frame Visual Quality | Individual frame aesthetic quality |
| Physical / Commonsense Realism | Physics plausibility and world-state consistency (VBench-2.0) |

---

## 6. Output Description

### Console Output
For each scenario, the script prints:
1. Dimension-level evidence score matrix (products × dimensions)
2. Aggregate scores + rankings + single-metric baseline annotation

### Figure Files
| Filename | Content |
|----------|---------|
| `fig1_radar_charts.png` | 4-scenario radar charts (dimension profiles) |
| `fig2_bar_charts.png` | 4-scenario horizontal bar charts (aggregate rankings) |
| `fig3_heatmap.png` | Full heatmap across all scenarios and dimensions |
| `fig4_baseline_comparison.png` | Framework vs single-metric baseline comparison |

### Data Files
| Filename | Content |
|----------|---------|
| `results_summary.xlsx` | Dimension scores + aggregate scores per scenario (multi-sheet) |
| `combined_aggregate_scores.csv` | Combined aggregate score table across all scenarios |

---

## 7. How to Run

```bash
# Run directly
python ai_selection_framework.py

# Or run section-by-section in Jupyter Notebook
jupyter notebook
```

---

## 8. Key Results at a Glance

| Scenario | Rank 1 | Score | Rank 2 | Score | Rank 3 | Score |
|----------|--------|-------|--------|-------|--------|-------|
| Coding Assistants | **Claude Code** | 0.8625 | Cursor | 0.8000 | Grok | 0.5125 |
| Academic Writing | **ChatGPT (GPT-5)** | 0.8500 | Claude | 0.7500 | Gemini | 0.6750 |
| Image Generation | **Seedream** | 0.9375 | Midjourney | 0.7750 | OpenAI Image Gen | 0.7500 |
| Video Generation | **Seedance 2.0** | 0.8875 | Sora 2 | 0.8125 | Veo 3 | 0.7125 |

> **Key framework vs baseline divergence**: In Academic Writing, the single-metric baseline selects Claude (writing quality = 0.95), but the multi-criteria framework recommends ChatGPT (GPT-5) once citation reliability (0.55) is factored in. In Video Generation, the baseline selects Sora 2 (physical realism = 0.95), but the framework recommends Seedance 2.0 for its balanced profile.

---

## 9. Extension Suggestions

1. **Adjust dimension weights**: Modify `coding_weights` (etc.) to implement task-specific reweighting
2. **Add new products**: Insert entries into `*_scores_raw` dictionaries; they are automatically included
3. **Add new scenarios**: Define `products / dimensions / weights / scores_raw` following the existing pattern and append to `SCENARIOS`
4. **Sensitivity analysis**: Perturb coded scores by ±0.05 to test ranking stability
5. **Weighted evidence tiers**: Assign different multipliers to primary vs secondary vs community evidence layers