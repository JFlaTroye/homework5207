import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.colors import LinearSegmentedColormap
import warnings

warnings.filterwarnings("ignore")

plt.rcParams.update({
    "figure.dpi": 150,
    "font.size": 11,
    "axes.titlesize": 12,
    "axes.labelsize": 11,
    "legend.fontsize": 9,
})

# ============================================================
# basic data
# ============================================================

# For each scenario: product -> Evidence scoring in four dimensions
coding_scores_raw = {
    "Claude Code": [0.95, 0.95, 0.85, 0.70],
    "Cursor":      [0.70, 0.85, 0.95, 0.70],
    "Grok":        [0.55, 0.40, 0.55, 0.55],
}
writing_scores_raw = {
    "ChatGPT (GPT-5)": [0.85, 0.85, 0.85, 0.85],
    "Claude":          [0.80, 0.70, 0.95, 0.55],
    "Gemini":          [0.75, 0.70, 0.70, 0.55],
}
image_scores_raw = {
    "Seedream":         [0.95, 0.90, 0.95, 0.95],
    "Midjourney":       [0.70, 0.65, 0.95, 0.80],
    "OpenAI Image Gen": [0.80, 0.75, 0.75, 0.70],
}
video_scores_raw = {
    "Seedance 2.0": [0.95, 0.90, 0.85, 0.85],
    "Sora 2":       [0.75, 0.65, 0.90, 0.95],
    "Veo 3":        [0.65, 0.55, 0.85, 0.80],
}

# 维度等权
weights = [0.25, 0.25, 0.25, 0.25]


# ============================================================
# Figure D：Research process Gantt chart
# ============================================================

tasks = [
    ("Topic Selection & Scope Definition",    1,  1.5, "Planning"),
    ("Literature Review – Coding Tools",      1,  3.0, "Literature"),
    ("Literature Review – Writing Tools",     1,  3.0, "Literature"),
    ("Literature Review – Image/Video Tools", 2,  2.5, "Literature"),
    ("Evidence Coding Scheme Design",         2,  1.5, "Methodology"),
    ("Benchmark Source Collection",           3,  2.0, "Data"),
    ("Evidence Scoring (Coding Scenario)",    4,  1.5, "Data"),
    ("Evidence Scoring (Writing Scenario)",   4,  1.5, "Data"),
    ("Evidence Scoring (Image Scenario)",     5,  1.5, "Data"),
    ("Evidence Scoring (Video Scenario)",     5,  1.5, "Data"),
    ("Framework Formula Design",              5,  1.0, "Methodology"),
    ("Python Analysis Code Development",      6,  2.0, "Analysis"),
    ("Sensitivity Analysis",                  7,  1.5, "Analysis"),
    ("Visualisation & Figure Generation",     8,  1.5, "Analysis"),
    ("Report Writing – Methodology",          6,  2.0, "Writing"),
    ("Report Writing – Results & Discussion", 8,  2.0, "Writing"),
    ("Peer Review & Revision",               10,  1.0, "Writing"),
    ("Final Submission",                     11,  0.5, "Planning"),
]

cat_colors = {
    "Planning":    "#E74C3C",
    "Literature":  "#3498DB",
    "Methodology": "#9B59B6",
    "Data":        "#E67E22",
    "Analysis":    "#27AE60",
    "Writing":     "#1ABC9C",
}

fig_d, ax_d = plt.subplots(figsize=(15, 9))
fig_d.patch.set_facecolor("#FAFAFA")
ax_d.set_facecolor("#FAFAFA")

for i, (task, start, dur, cat) in enumerate(tasks):
    color = cat_colors[cat]
    ax_d.barh(i, dur, left=start, height=0.6,
              color=color, edgecolor="white", linewidth=1.2,
              alpha=0.88)
    ax_d.text(start + dur / 2, i, task,
              ha="center", va="center",
              fontsize=7.8, color="white", fontweight="bold")

ax_d.set_yticks(range(len(tasks)))
ax_d.set_yticklabels([t[0] for t in tasks], fontsize=8.5)
ax_d.set_xlabel("Project Week", fontsize=11)
ax_d.set_xlim(0.5, 12)
ax_d.set_xticks(range(1, 12))
ax_d.set_xticklabels([f"W{i}" for i in range(1, 12)])
ax_d.invert_yaxis()

legend_patches = [mpatches.Patch(color=c, label=l, alpha=0.88)
                  for l, c in cat_colors.items()]
ax_d.legend(handles=legend_patches, loc="lower right",
            ncol=3, fontsize=9, title="Task Category",
            title_fontsize=9, framealpha=0.9)


for week, label in [(3.5, "Phase 1\nFoundation"),
                    (6.5, "Phase 2\nAnalysis"),
                    (9.5, "Phase 3\nWriting")]:
    ax_d.axvline(week, color="#CCCCCC", lw=1.5, ls="--", alpha=0.7)
    ax_d.text(week, -0.8, label, ha="center", fontsize=8,
              color="#888888", style="italic")

ax_d.set_title("Figure D – Research Process Gantt Chart\n"
               "Project Timeline & Task Distribution (Group 4, DSAI5207)",
               fontsize=13, fontweight="bold", pad=12)
ax_d.spines["top"].set_visible(False)
ax_d.spines["right"].set_visible(False)
plt.tight_layout()
plt.savefig("figD_gantt_chart.png", bbox_inches="tight", facecolor="#FAFAFA")
plt.show()
print("Figure D saved")


# ============================================================
# Figure E：Framework vs Single Indicator baseline - Ranking consistency matrix
# Calculate directly using the raw scores in this file
# ============================================================

import matplotlib.gridspec as gridspec

fig_e, axes_e = plt.subplots(1, 4, figsize=(17, 5))
fig_e.patch.set_facecolor("#F8F8F8")

# To maintain the original beautiful dimension labels, a "dimension alias" dictionary is defined here
DIM_LABEL_ALIASES = {
    "Coding Assistants": {
        "Correctness": "Correctness",
        "Repo-level Issue Resolution": "Repo-level",
        "Debugging / Self-repair": "Debugging",
        "Cross-language Generalisation": "Cross-lang",
    },
    "Academic Writing": {
        "Instruction Following": "Instruction\nFollow",
        "Long-form Factuality": "Long-form\nFactuality",
        "Overall Writing Quality": "Writing\nQuality",
        "Citation Reliability": "Citation\nReliability",
    },
    "Image Generation": {
        "Text Alignment": "Text\nAlign",
        "Compositional Prompt Handling": "Compositional",
        "Human Preference / Perceptual Quality": "Human\nPreference",
        "Detail Fidelity": "Detail\nFidelity",
    },
    "Video Generation": {
        "Temporal Consistency": "Temporal\nConsistency",
        "Controllability": "Controllability",
        "Per-frame Visual Quality": "Visual\nQuality",
        "Physical / Commonsense Realism": "Physical\nRealism",
    },
}

# Organize the data of the four scenarios into a list
scenario_data = [
    ("Coding Assistants",
     coding_scores_raw,
     ["Correctness",
      "Repo-level Issue Resolution",
      "Debugging / Self-repair",
      "Cross-language Generalisation"]),
    ("Academic Writing",
     writing_scores_raw,
     ["Instruction Following",
      "Long-form Factuality",
      "Overall Writing Quality",
      "Citation Reliability"]),
    ("Image Generation",
     image_scores_raw,
     ["Text Alignment",
      "Compositional Prompt Handling",
      "Human Preference / Perceptual Quality",
      "Detail Fidelity"]),
    ("Video Generation",
     video_scores_raw,
     ["Temporal Consistency",
      "Controllability",
      "Per-frame Visual Quality",
      "Physical / Commonsense Realism"]),
]

for ax_idx, (scenario_name, raw, dims) in enumerate(scenario_data):
    ax = axes_e[ax_idx]
    ax.set_facecolor("#F8F8F8")

    products = list(raw.keys())

    # Multi-criteria scoring
    mc_scores = {p: float(np.dot(raw[p], weights)) for p in products}
    mc_rank = sorted(products, key=lambda p: mc_scores[p], reverse=True)

    # Dimension alias, used for X-axis labels
    alias_map = DIM_LABEL_ALIASES.get(scenario_name, {})
    dim_labels = [alias_map.get(d, d.replace(" / ", "\n")) for d in dims]
    n_dims = len(dim_labels)

    # Construct the ranking matrix: row = product, column = [Multiple criteria, dim1, dim2,...]
    matrix = np.zeros((len(products), n_dims + 1))
    for pi, p in enumerate(products):
        # Multi-criterion ranking
        matrix[pi, 0] = mc_rank.index(p) + 1
        # Rankings in each dimension
        for di in range(n_dims):
            dim_scores = {pp: raw[pp][di] for pp in products}
            dim_rank = sorted(products, key=lambda pp: dim_scores[pp], reverse=True)
            matrix[pi, di + 1] = dim_rank.index(p) + 1

    # Draw a heat map: The smaller the ranking, the greener
    cmap = LinearSegmentedColormap.from_list(
        "rank", ["#27AE60", "#F39C12", "#E74C3C"], N=len(products)
    )
    im = ax.imshow(matrix, cmap=cmap, vmin=0.5,
                   vmax=len(products) + 0.5, aspect="auto")

    # label #1/#2/#3
    for pi in range(len(products)):
        for di in range(n_dims + 1):
            rank_val = int(matrix[pi, di])
            ax.text(di, pi, f"#{rank_val}",
                    ha="center", va="center",
                    fontsize=10, fontweight="bold", color="white")

    ax.set_xticks(range(n_dims + 1))
    ax.set_xticklabels(["Multi-\nCriteria"] + dim_labels, fontsize=7.5)

    # The product name
    def shorten_name(p: str) -> str:
        p = p.replace(" (GPT-5)", "")
        p = p.replace(" Image Gen", "\nImgGen")
        return p

    ax.set_yticks(range(len(products)))
    ax.set_yticklabels([shorten_name(p) for p in products], fontsize=8.5)

    ax.set_title(scenario_name.replace(" ", "\n"),
                 fontweight="bold", fontsize=10, pad=8)

    # Highlight multi-criterion columns
    for pi in range(len(products)):
        ax.add_patch(plt.Rectangle(
            (-0.5, pi - 0.5), 1, 1,
            fill=False, edgecolor="gold", linewidth=2.5, zorder=5
        ))

fig_e.suptitle(
    "Figure E – Ranking Consistency Matrix: Multi-Criteria vs Single-Dimension Rankings\n"
    "(Gold border = Multi-Criteria column; #1 = best)",
    fontsize=12, fontweight="bold", y=1.02
)
plt.tight_layout()
plt.savefig("figE_ranking_consistency.png", bbox_inches="tight", facecolor="#F8F8F8")
plt.show()
print("Figure E saved")


# ============================================================
# Figure F：Cross-scene Winner comprehensive radar chart
# Automatically calculate the winner & score from raw scores in this file
# ============================================================

# Help function: Given the raw scores of a scene, calculate the winner name and aggregate score
def get_winner_for_scenario(raw_dict):
    products = list(raw_dict.keys())
    agg_scores = {p: float(np.dot(raw_dict[p], weights)) for p in products}
    winner = max(agg_scores, key=agg_scores.get)
    return winner, agg_scores[winner]

#  winners_data：{ "Claude Code\n(Coding)": [dim1, dim2, dim3, dim4, aggregate] }
winners_data = {}

# Coding
winner_name, winner_score = get_winner_for_scenario(coding_scores_raw)
winners_data[f"{winner_name}\n(Coding)"] = coding_scores_raw[winner_name] + [winner_score]

# Writing
winner_name, winner_score = get_winner_for_scenario(writing_scores_raw)
winners_data[f"{winner_name}\n(Writing)"] = writing_scores_raw[winner_name] + [winner_score]

# Image
winner_name, winner_score = get_winner_for_scenario(image_scores_raw)
winners_data[f"{winner_name}\n(Image)"] = image_scores_raw[winner_name] + [winner_score]

# Video
winner_name, winner_score = get_winner_for_scenario(video_scores_raw)
winners_data[f"{winner_name}\n(Video)"] = video_scores_raw[winner_name] + [winner_score]

# Define the radar dimension label
radar_dims = [
    "Dim 1\n(Accuracy)",
    "Dim 2\n(Task-specific)",
    "Dim 3\n(Quality)",
    "Dim 4\n(Reliability)",
    "Aggregate\nScore",
]

N = len(radar_dims)
angles = np.linspace(0, 2 * np.pi, N, endpoint=False).tolist()
angles += angles[:1]

fig_f, ax_f = plt.subplots(figsize=(9, 9), subplot_kw=dict(polar=True))
fig_f.patch.set_facecolor("#F5F5F5")
ax_f.set_facecolor("#F5F5F5")
ax_f.set_theta_offset(np.pi / 2)
ax_f.set_theta_direction(-1)

ax_f.set_xticks(angles[:-1])
ax_f.set_xticklabels(radar_dims, size=10)
ax_f.set_ylim(0, 1)
ax_f.set_yticks([0.2, 0.4, 0.6, 0.8, 1.0])
ax_f.set_yticklabels(["0.2", "0.4", "0.6", "0.8", "1.0"], size=8)

winner_colors = ["#4C72B0", "#55A868", "#DD8452", "#C44E52"]

for (wname, vals), color in zip(winners_data.items(), winner_colors):
    v = vals + vals[:1]
    ax_f.plot(angles, v, "o-", linewidth=2.2, color=color, label=wname)
    ax_f.fill(angles, v, alpha=0.13, color=color)
    # Mark the maximum dimension value of this winner
    max_idx = int(np.argmax(vals))
    ax_f.annotate(f"{vals[max_idx]:.2f}",
                  xy=(angles[max_idx], vals[max_idx]),
                  xytext=(angles[max_idx], vals[max_idx] + 0.06),
                  ha="center", fontsize=8, color=color, fontweight="bold")

ax_f.legend(loc="upper right", bbox_to_anchor=(1.42, 1.18),
            fontsize=9.5, title="Scenario Winners", title_fontsize=10,
            framealpha=0.9)
ax_f.set_title(
    "Figure F – Cross-scenario Winners\nComprehensive Capability Profile\n"
    "(Dimensions abstracted; not strictly comparable across tasks)",
    size=13, fontweight="bold", pad=20
)

plt.tight_layout()
plt.savefig("figF_winners_radar.png", bbox_inches="tight", facecolor="#F5F5F5")
plt.show()
print("Figure F saved")

print("\nAll extra figures generated: figD_gantt_chart.png, "
      "figE_ranking_consistency.png, figF_winners_radar.png")
